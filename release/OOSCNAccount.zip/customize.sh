REPLACE="
/system/app/Account
/product/app/Account
"